#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define S_LIMIT 25
#define T_LIMIT 5
#define STUD_LIMIT 10
#define TUTOR_LIMIT 5

struct sessions {
    char s_code[10];
    char title[50];
    char day[15];
    char time[10];
    char location[10];
    char t_code[5];
};

struct admin {
    char AiD[5];
    char Apassword[5];
};

struct tutors {
    char Tid[5];
    char Tname[20];
    char Tpassword[10];
    char Tpersonalemail[50];
    char Tcoursetitle[50];
};

struct students {
    char tpnumber[10];
    char Sname[40];
    char Spassword[6];
    char Smajor[10];
    char Spersonalemail[30];
};

struct sessions session_info[TUTOR_LIMIT];
char tutor_id[10]; 

FILE *fp;
FILE *fa;
FILE *fs;
FILE *pyp;
FILE *java;
FILE *c;
FILE *web;
FILE *csharp;

int choice, admin_choice; 
char line[500];
int no_admins, no_tutors, no_students, no_sessions;

char enroll[10];
int enroll_stud;
char studtp[STUD_LIMIT][10];
char tpsession[10];
char stdsession[10];
char enrolltp[10];

char pyline[500];
char javaline[500];
char cline[500];
char csharpline[500];
char webline[500];

int k, i, m;

char user[10];
char pw[10];
char t_user[10] = {0};
char t_pass[6];
char stud_user[10];
char stud_pass[6];

struct sessions info[S_LIMIT];

void display_session();
void student_enroll();
void enroll_student();
void student_sessions(int sc);
void tutor_sessions();
void add_session();
void admin_login();
void admin_menu();
void admin_register();
void student_registration();
void tutor_registration();

int main(){
    fa = fopen("tutors.txt","r");
    struct tutors tutor;
    printf("\n\t\t\tWelcome to the APU Programming Cafe management system!\n");
    printf("\n\t\t\t----------------------------------------------------------\n");
    while (1)
    {
        printf("\nMenu:");
        printf("\n1. Admin");
        printf("\n2. Tutor");
        printf("\n3. Student");
        printf("\n4. Exit");
        printf("\nEnter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                admin_login();
                break;
            case 2:
                printf("\nTutor Login\n");
                char tutor_id[10];
                char tutor_password[10];
                printf("\nPlease enter your ID: "); 
                scanf("%s", tutor_id);
                printf("Please enter your password: "); 
                scanf("%s", tutor_password);
                struct tutors t;
                FILE* ft = fopen("tutors.txt", "r");
                int is_valid_tutor = 0;
                while(fscanf(ft, "%s", t.Tid) != EOF) {
                    fscanf(ft, "%s", t.Tname);
                    fscanf(ft, "%s", t.Tpassword);
                    fscanf(ft, "%s", t.Tpersonalemail);
                    fscanf(ft, "%s", t.Tcoursetitle);
                    if (strcmp(tutor_id, t.Tid) == 0 && strcmp(tutor_password, t.Tpassword) == 0) {
                        is_valid_tutor = 1;
                        break;
                    }
                }
                fclose(ft);
                if(is_valid_tutor) {
                    int tutor_choice;
                    do
                    {
                        printf("\nTutor Menu:");
                        printf("\n1. Display Sessions");
                        printf("\n2. Logout");
                        printf("\nEnter your choice: ");
                        scanf("%d", &tutor_choice);

                        switch (tutor_choice)
                        {
                            case 1:
                                tutor_sessions(tutor_id);
                                break;
                            case 2:
                                printf("Logging out from tutor account...\n");
                                main();
                                break;
                            default:
                                printf("\nInvalid choice. Please try again.\n");
                        }
                    } while (tutor_choice != 2);
                } else {
                    printf("\nInvalid tutor credentials. Please try again.\n");
                }
                break;
            case 3:
                printf("\nStudent Login\n");
                char student_tp[10];
                char student_password[10];
                printf("\nPlease enter your TP: "); 
                scanf("%s", student_tp);
                printf("Please enter your password: "); 
                scanf("%s", student_password);
                struct students s;
                FILE* fs = fopen("students.txt", "r");
                int is_valid_student = 0;
                while(fscanf(fs, "%s %s", s.tpnumber, s.Spassword) != EOF) {
                    if (strcmp(student_tp, s.tpnumber) == 0 && strcmp(student_password, s.Spassword) == 0) {
                        is_valid_student = 1;
                        break;
                    }
                }
                fclose(fs);
                if(is_valid_student) {
                    int student_choice;
                    do
                    {
                        printf("\nStudent Menu:");
                        printf("\n1. Enroll Session");
                        printf("\n2. View Sessions");
                        printf("\n3. Logout");
                        printf("\nEnter your choice: ");
                        scanf("%d", &student_choice);

                        switch (student_choice)
                        {
                            case 1:
                                student_sessions(is_valid_student);
                                break;
                            case 2:
                                student_enroll();
                                break;
                            case 3:
                                printf("Logging out from student account...\n");
                                main();
                                break;
                            default:
                                printf("Invalid choice. Please try again.\n");
                        }
                    } while (student_choice != 2);
                }
                else
                {
                    printf("Invalid TP number or password. Access denied.\n");
                }
                break;

            case 4:
                printf("Exiting the program...\n");
                fclose(fa);
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}

void display_session() {
    struct sessions s;
    struct students stud;
    char tp[10];
    char *session_files[] = {"pyp.txt", "csharp.txt", "c.txt", "java.txt", "web.txt"};
    char *session_codes[] = {"PYP101", "CSP105", "CPL103", "JAV102", "WEB104"};
    int i, j;
    FILE *session_students, *session, *student;

    session = fopen("session.txt", "r");
    student = fopen("students.txt", "r");

    if (session == NULL) {
        printf("Error opening session.txt\n");
        return; 
    }

    if (student == NULL) {
        printf("Error opening student.txt\n");
        return;  
    }

    printf("Student Name Session Code Tutor Code Location\n");
    printf("------------------------------------------------------------------------------------------\n");

    for(i = 0; i < 5; i++) {
        session_students = fopen(session_files[i], "r");
        if (session_students == NULL) {
            printf("Error opening %s\n", session_files[i]);
            continue;
        }
        
        while(fgets(tp, sizeof(tp), session_students)) {
            tp[strcspn(tp, "\n")] = '\0';

            rewind(session);
            while(fscanf(session, "%s\n%*[^\n]\n%*[^\n]\n%*[^\n]\n%s\n%s", s.s_code, s.location, s.t_code) != EOF) {
                if(strcmp(session_codes[i], s.s_code) == 0) {
                    rewind(student);
                    while(fscanf(student, "%s\n%s\n%*[^\n]\n%*[^\n]\n%*[^\n]", stud.tpnumber, stud.Sname) != EOF) {
                        if(strcmp(stud.tpnumber, tp) == 0) {
                            printf("%s %s %s %s\n", stud.Sname, s.s_code, s.t_code, s.location);
                            break;
                        }
                    }
                    break;
                }
            }
        }
        fclose(session_students);
    }

    fclose(session);
    fclose(student);
}



void student_enroll()
{
    printf("\nThere are 5 language sessions where to enroll: Python, C, C Sharp, Java, Web Development\n");
	printf("\nSession code are as follows:\n\n 1. Python\t\tPYP101\n 2. C\t\t\tCPL103\n 3. C Sharp\t\tCSP105\n 4. Java\t\tJAV102\n 5. Web Development\tWEB104");
	
	printf("\n\nEnter the session code to enroll into a session: "); scanf("%s", &stdsession);
	
	if (strcmp(stdsession,"PYP101")==0){
		pyp = fopen("pyp.txt","a");
		printf("\n\nEnter your TP Number to enroll: "); scanf("%s", &enrolltp);
		fprintf(pyp,"\n%s", enrolltp);
	}
	else if (strcmp(stdsession,"CPL103")==0){
		c = fopen("c.txt","a");
		printf("\n\nEnter your TP Number to enroll: "); scanf("%s", &enrolltp);
		fprintf(c,"\n%s", enrolltp);
	}
	else if (strcmp(stdsession,"CSP105")==0){
		csharp = fopen("csharp.txt","a");
		printf("\n\nEnter your TP Number to enroll: "); scanf("%s", &enrolltp);
		fprintf(csharp,"\n%s", enrolltp);
	}
	else if (strcmp(stdsession,"JAV102")==0){
		java = fopen("java.txt","a");
		printf("\n\nEnter your TP Number to enroll: "); scanf("%s", &enrolltp);
		fprintf(java,"\n%s", enrolltp);
	}
	else if (strcmp(stdsession,"WEB104")==0){
		web = fopen("web.txt","a");
		printf("\n\nEnter your TP Number to enroll: "); scanf("%s", &enrolltp);
		fprintf(web,"\n%s", enrolltp);
	}
	else{
		printf("\nSession code is wrong or does not exist");
	}
	printf("\nSuccessfully enrolled to sessions");
	fclose(pyp);
    fclose(c);
    fclose(csharp);
    fclose(java);
    fclose(web);
}

void student_sessions(int sc){
    int found = 0;
    char pyline[100], javaline[100], cline[100], csharpline[100], webline[100];
	
    fp = fopen("session.txt", "r"); 
    pyp = fopen("pyp.txt", "r"); 
    java = fopen("java.txt", "r"); 
    c = fopen("c.txt", "r"); 
    csharp = fopen("csharp.txt", "r"); 
    web = fopen("web.txt", "r");
	
    if (fp == NULL || pyp == NULL || java == NULL || c == NULL || csharp == NULL || web == NULL) {
        printf("Files do not exist \n");
        return;
    }

    printf("\nEnter your TP [TPXXXXXX]: "); 
    fgets(tpsession, sizeof(tpsession), stdin);
    tpsession[strcspn(tpsession, "\n")] = 0;

    while(fgets(pyline, sizeof(pyline), pyp) != NULL){
        if(strstr(pyline, tpsession)){
            found = 1;
            break;
        }
    }
    


    if (found) {

        printf("\nCode\tTitle\t\t\tDay\t\tTime\t\tLocation\tTutor Code\n");
        printf("==================================================================================================\n");

        while(fscanf(fp, "%s %s %s %s %s %s\n", info[sc].s_code, info[sc].title, info[sc].day, info[sc].time, info[sc].location, info[sc].t_code) == 6){
            printf("%s  %s  \t%s  \t%s  \t%s  \t%s\n", info[sc].s_code, info[sc].title, info[sc].day, info[sc].time, info[sc].location, info[sc].t_code);
        }
    }

    if (!found) {
        printf("\nNo enrolled sessions found for %s.\n", tpsession);
    }
	
    fclose(fp);
    fclose(pyp);
    fclose(java);
    fclose(c);
    fclose(csharp);
    fclose(web);
}


void tutor_sessions(char* tutor_id) {
    int foundd = 0;
    int tc;

    fp = fopen("session.txt", "r"); 

    if (fp == NULL) {
        printf("\nFile does not exist\n");
        return;
    }

    for (tc=0; tc <= TUTOR_LIMIT; tc++) {
        fgets(session_info[tc].s_code, sizeof(session_info[tc].s_code), fp);
        fgets(session_info[tc].title, sizeof(session_info[tc].title), fp);
        fgets(session_info[tc].day, sizeof(session_info[tc].day), fp);
        fgets(session_info[tc].time, sizeof(session_info[tc].time), fp);
        fgets(session_info[tc].location, sizeof(session_info[tc].location), fp);
        fgets(session_info[tc].t_code, sizeof(session_info[tc].t_code), fp);

        session_info[tc].s_code[strcspn(session_info[tc].s_code, "\n")] = 0;
        session_info[tc].title[strcspn(session_info[tc].title, "\n")] = 0;
        session_info[tc].day[strcspn(session_info[tc].day, "\n")] = 0;
        session_info[tc].time[strcspn(session_info[tc].time, "\n")] = 0;
        session_info[tc].location[strcspn(session_info[tc].location, "\n")] = 0;
        session_info[tc].t_code[strcspn(session_info[tc].t_code, "\n")] = 0;
        
    }

    printf("\nTutor Sessions:\n");

    for (tc=0; tc <= TUTOR_LIMIT; tc++) {
        if (strcmp(session_info[tc].t_code, tutor_id) == 0) {
            foundd = 1;
            printf("\nSession Code\tSession Title\t\tSession Day\tSession Time\tLocation\tTutor Code\n");
            printf("======================================================================================================\n");
            printf("%s \t\t %s \t\t %s \t %s \t %s \t\t %s \n", session_info[tc].s_code, session_info[tc].title, session_info[tc].day, session_info[tc].time, session_info[tc].location, session_info[tc].t_code);    
        }
    }

    if (foundd == 0){
        printf("No sessions found for this tutor.\n");
    }

    fclose(fp);
}

void add_session() {
    struct sessions info;
    
    printf("\nEnter the session details: \n");
    printf("\nSession code: ");
    scanf("%s", info.s_code);
    printf("\nTitle: ");
    scanf(" %[^\n]", info.title);  
    printf("\nDay: ");
    scanf("%s", info.day);
    printf("\nTime: ");
    scanf("%s", info.time);
    printf("\nLocation: ");
    scanf("%s", info.location);
    printf("\nTutor code: ");
    scanf("%s", info.t_code);

    FILE *file = fopen("session.txt", "a");
    if (file == NULL) {
        printf("Error opening file!\n");
        exit(1);
    }

    fprintf(file, "%s\n%s\n%s\n%s\n%s\n%s\n", 
            info.s_code, info.title, info.day, info.time, info.location, info.t_code);

    fclose(file);
    printf("Session successfully added.\n");
}

void student_registration() {
    struct students stud;
    fs = fopen("students.txt", "a+");

    if (fs == NULL) {
        printf("\nFile does not exist\n");
    }

    printf("\nHow many students do you want to register: ");
    scanf("%d", &no_students);

    if (no_students <= STUD_LIMIT) {
        for (k = 1; k <= no_students; k++) {
            printf("\nEnter the student's TP Number: ");
            scanf("%s", &stud.tpnumber);
            printf("\nEnter the student's name: ");
            scanf("%s", &stud.Sname);
            printf("\nEnter the student's password: ");
            scanf("%s", &stud.Spassword);
            printf("\nEnter the student's major: ");
            scanf("%s", &stud.Smajor);
            printf("\nEnter the student's personal email: ");
            scanf("%s", &stud.Spersonalemail);

            fprintf(fs, "\n%s %s", stud.tpnumber, stud.Spassword);
            fprintf(fs, "\n%s", stud.Sname);
            fprintf(fs, "\n%s", stud.Smajor);
            fprintf(fs, "\n%s\n", stud.Spersonalemail);
        }
    }

    printf("\nRecord(s) Updated Successfully!");
    fclose(fs);
}

void tutor_registration(){
    struct tutors t;
    fa = fopen("tutors.txt", "a+");

    if (fa == NULL) {
        printf("\nFile does not exist\n");
        return;
    }

    printf("\nExample: T01 T02 T03 T04 T05 T06 T07 T08 T09 T10");
    printf("\nEnter the tutor's ID: "); 
    scanf("%s", t.Tid);
    printf("\nEnter the tutor's password: "); 
    scanf("%s", t.Tname);
    printf("\nEnter the tutor's name: "); 
    scanf("%s", t.Tpassword);
    printf("\nEnter the tutor's personal email: ");
    scanf("%s", t.Tpersonalemail);
    printf("\nEnter the programming language taught by the tutor: "); 
    scanf("%s", t.Tcoursetitle);

    fprintf(fa, "\n%s %s", t.Tid, t.Tpassword); 
    fprintf(fa, "\n%s", t.Tname);
    fprintf(fa, "\n%s", t.Tpersonalemail);
    fprintf(fa, "\n%s\n", t.Tcoursetitle);

    printf("\nTutor Added Successfully!");
    fclose(fa);
    admin_menu();
}

void admin_login(){
    printf("\n Username and password: admin");
    printf("\nPlease enter your username: "); 
    scanf("%s", user);
    printf("Please enter your password: "); 
    scanf("%s", pw);

    if (strcmp(user, "admin") == 0 && strcmp(pw, "admin") == 0) {
        admin_menu();
    }
    else {
        printf("\nInvalid Input, Try Again\n");
        admin_login();
    }
}

void admin_menu(){
	
	do{
		printf("\n\nPlease choose what you want to do: \n");
		printf("1. Tutor Registration\n2. Student Registration\n3. Insert New Session\n4. Display Session Details\n5. Enroll Student\n6. Back\n");
		printf("\nPlease enter your choice: ");
		scanf("%d",&admin_choice);
		
		switch(admin_choice){
			
			case 1:
				tutor_registration(); 
				break;
			case 2:
				student_registration();
				break;
			case 3:
				add_session();
				break;
			case 4:
				display_session();
				break;
			case 5:
				student_enroll();
				break;
            case 6:
                main();
                break;
			default:
				printf("Invalid Choice, Please Try Again");
		}
	}
	while(admin_choice!=6);
}